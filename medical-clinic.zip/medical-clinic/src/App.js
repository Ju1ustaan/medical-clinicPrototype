import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Home from "./pages/Home";
import Login from "./components/Login";
import Personal from "./pages/Personal";

const App = () => {
  return (
    <div>
      <Router>
      <Header/>
        <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        </Routes>
        <Personal/>
        
      </Router>
    </div>
  );
}

export default App;
