import React from 'react'
import Card from '../components/Card'

const Personal = () => {
    return (
        <div className='personal bg-gradient-to-r from-cyan-500 to-blue-500'>
            <div className='container'>
                <div className='pesonal__wrapper'>
                    <h2 className='personal__title'>Наши специалисты</h2>
                    <div className='personal__wrapper-grid'>
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        <Card />
                        
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Personal