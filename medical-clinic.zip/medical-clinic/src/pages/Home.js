import React from 'react'

const Home = () => {
  
  return (
    <div className="home bg-gradient-to-r from-cyan-500 to-blue-500">
    <div className='container'>
        <div className='home__wrapper'>
          <h2 className='home__title'>Главная</h2>
        <div className="first-col">
          <div className="home__col1"><p className='home__subtitle'>Наши специалисты</p> <p className='home__desc'>Выберите нужного вам специалиста. Здесь вы найдете лучших врачей.</p></div>
          <div className="home__col2"><p className='home__subtitle'>Запись</p> <p className='home__desc'>Теперь что бы записаться на прием к врачу, не нужно стоять в киллометровых очередях.</p></div>
          <div className="home__col3"><p className='home__subtitle'>Контакты</p> <p className='home__desc'>С нами можно связатся всеми удобными способами</p></div>
          <div className="home__col4"><p className='home__subtitle'>Подробнее об услуге</p> <p className='home__desc'>Узнайте подробнее как работает онлайн запись.</p></div>
          <div className="home__col5"><p className='home__subtitle'>Врачам</p> <p className='home__desc'>Регистрация врача в нашем сервисе</p></div>
          <div className="home__col6"><p className='home__subtitle'>Категории</p> <p className='home__desc'>Удобный поиск нужных вам специалистов</p></div>
        </div>
    </div>
  </div>
  
</div>

  )
}

export default Home