import React from 'react'
import image from '../accets/galina-pupkova.jpg'

const Card = () => {
  return (
    <div className='card'>
        <div className='card__img'>
            <img src={image}/>
        </div>
        <div className='card__info'>
            <p className='card__name'>Галина Пупкова</p>
            <p className='card__special'>Педиатр</p>
            <p className='card__price'>3000 р.</p>
        </div>
    </div>
  )
}

export default Card