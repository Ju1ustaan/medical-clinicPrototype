import React from 'react'
import { NavLink } from 'react-router-dom'
import Login from '../components/Login'

const Header = () => {
  
    return (
        <div>
            


            <body class="bg-white dark:bg-gray-900">
                <header>
                    <input type="checkbox" name="hbr" id="hbr" class="hbr peer" hidden aria-hidden="true"></input>
                    <nav class="fixed z-20 w-full bg-gradient-to-r from-cyan-500 to-blue-500 backdrop-blur navbar shadow-2xl shadow-gray-600/5 border-b border-gray-100 dark:border-gray-800 peer-checked:navbar-active dark:shadow-none">
                        <div class="xl:container m-auto px-6 md:px-12 lg:px-6">
                            <div class="flex flex-wrap items-center justify-between gap-6 md:py-3 md:gap-0 lg:py-5">

                                <a class="relative z-10" href="#" aria-label="logo">
                                    MedicalClinic
                                </a>


                                <div class="navmenu hidden w-full flex-wrap justify-end items-center mb-16 space-y-8 p-6 border border-gray-100 rounded-3xl shadow-2xl shadow-gray-300/20 bg-white dark:bg-gray-800 lg:space-y-0 lg:p-0 lg:m-0 lg:flex md:flex-nowrap lg:bg-transparent lg:w-7/12 lg:shadow-none dark:shadow-none dark:border-gray-700 lg:border-0">
                                    <div class="text-gray-600 dark:text-gray-300 lg:pr-4">

                                        <NavLink to="/">
                                            Главная
                                        </NavLink>

                                        <NavLink to="/">
                                            Персонал
                                        </NavLink>

                                        <NavLink to="/" >
                                            Подробнее
                                        </NavLink>

                                    </div>

                                    <div class="w-full space-y-2 border-primary/10 dark:border-gray-700 flex flex-col -ml-1 sm:flex-row lg:space-y-0 md:w-max lg:border-l">

                                        <NavLink to="/login">
                                            <button type="button" class="border border-blue-500 bg-blue-700 text-white rounded-md px-4 py-2 m-2 transition duration-500 ease select-none hover:bg-green-600 focus:outline-none focus:shadow-outline">
                                                Login
                                            </button>
                                        </NavLink>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </nav>
                </header>

            </body>
            {
                
            }
        </div>
    )
}

export default Header